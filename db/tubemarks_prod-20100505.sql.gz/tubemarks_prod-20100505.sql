-- MySQL dump 10.11
--
-- Host: localhost    Database: tubemarks_prod
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `marks` (
  `id` int(11) NOT NULL auto_increment,
  `video_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `rating` int(11) default NULL,
  `category` int(11) default NULL,
  `description` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `marks`
--

LOCK TABLES `marks` WRITE;
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
INSERT INTO `marks` VALUES (2,2,2,NULL,NULL,NULL,'2008-04-27 13:46:51','2008-04-27 13:46:51'),(4,4,2,NULL,NULL,NULL,'2008-04-28 07:13:19','2008-04-28 07:13:19'),(5,5,4,NULL,NULL,NULL,'2008-04-28 10:02:13','2008-04-28 10:02:13'),(8,4,5,NULL,NULL,NULL,'2008-04-28 10:16:42','2008-04-28 10:16:42'),(9,8,5,NULL,NULL,NULL,'2008-04-28 10:18:31','2008-04-28 10:18:31'),(15,14,2,NULL,NULL,NULL,'2008-04-29 12:54:58','2008-04-29 12:54:58'),(16,15,2,NULL,NULL,NULL,'2008-04-30 09:40:15','2008-04-30 09:40:15'),(17,16,8,NULL,NULL,NULL,'2008-04-30 09:56:36','2008-04-30 09:56:36'),(18,17,2,NULL,NULL,NULL,'2008-05-01 09:58:02','2008-05-01 09:58:02'),(19,18,6,NULL,NULL,NULL,'2008-05-01 10:15:22','2008-05-01 10:15:22'),(20,19,2,NULL,NULL,NULL,'2008-05-02 02:50:11','2008-05-02 02:50:11'),(21,18,5,NULL,NULL,NULL,'2008-05-02 06:05:34','2008-05-02 06:05:34'),(22,20,2,NULL,NULL,NULL,'2008-05-02 07:29:43','2008-05-02 07:29:43'),(24,21,10,NULL,NULL,NULL,'2008-05-02 13:24:14','2008-05-02 13:24:14'),(25,22,10,NULL,NULL,NULL,'2008-05-02 13:25:02','2008-05-02 13:25:02'),(26,23,10,NULL,NULL,NULL,'2008-05-02 13:25:41','2008-05-02 13:25:41'),(27,24,10,NULL,NULL,NULL,'2008-05-02 13:27:26','2008-05-02 13:27:26'),(28,25,10,NULL,NULL,NULL,'2008-05-02 13:30:13','2008-05-02 13:30:13'),(29,26,10,NULL,NULL,NULL,'2008-05-02 13:30:59','2008-05-02 13:30:59'),(30,27,10,NULL,NULL,NULL,'2008-05-02 13:38:38','2008-05-02 13:38:38'),(31,28,10,NULL,NULL,NULL,'2008-05-02 13:50:31','2008-05-02 13:50:31'),(32,29,6,NULL,NULL,NULL,'2008-05-02 14:00:28','2008-05-02 14:00:28'),(33,30,2,NULL,NULL,NULL,'2008-05-02 14:46:33','2008-05-02 14:46:33'),(34,31,11,NULL,NULL,NULL,'2008-05-09 03:52:48','2008-05-09 03:52:48'),(35,32,5,NULL,NULL,NULL,'2008-05-10 13:12:43','2008-05-10 13:12:43'),(36,33,5,NULL,NULL,NULL,'2008-05-11 10:44:20','2008-05-11 10:44:20'),(37,34,5,NULL,NULL,NULL,'2008-05-12 02:09:07','2008-05-12 02:09:07'),(38,35,13,NULL,NULL,NULL,'2008-05-13 04:12:35','2008-05-13 04:12:35'),(39,36,13,NULL,NULL,NULL,'2008-05-13 04:13:50','2008-05-13 04:13:50'),(40,37,13,NULL,NULL,NULL,'2008-05-13 04:16:21','2008-05-13 04:16:21'),(41,38,13,NULL,NULL,NULL,'2008-05-13 04:17:21','2008-05-13 04:17:21'),(42,39,5,NULL,NULL,NULL,'2008-05-13 14:15:57','2008-05-13 14:15:57'),(43,40,5,NULL,NULL,NULL,'2008-05-13 14:18:54','2008-05-13 14:18:54'),(44,41,14,NULL,NULL,NULL,'2008-05-14 09:11:50','2008-05-14 09:11:50'),(45,42,2,NULL,NULL,NULL,'2008-05-19 15:49:46','2008-05-19 15:49:46'),(46,43,2,NULL,NULL,NULL,'2008-05-22 05:42:13','2008-05-22 05:42:13'),(48,45,2,NULL,NULL,NULL,'2008-05-23 15:19:33','2008-05-23 15:19:33'),(49,46,6,NULL,NULL,NULL,'2008-05-26 13:41:21','2008-05-26 13:41:21'),(50,47,15,NULL,NULL,NULL,'2008-05-27 11:05:24','2008-05-27 11:05:24'),(51,37,2,NULL,NULL,NULL,'2008-05-28 11:57:00','2008-05-28 11:57:00'),(52,48,2,NULL,NULL,NULL,'2008-06-02 04:07:17','2008-06-02 04:07:17'),(53,49,13,NULL,NULL,NULL,'2008-06-06 05:04:44','2008-06-06 05:04:44'),(54,50,16,NULL,NULL,NULL,'2008-06-17 07:32:55','2008-06-17 07:32:55'),(55,51,2,NULL,NULL,NULL,'2008-07-30 04:45:08','2008-07-30 04:45:08'),(56,52,2,NULL,NULL,NULL,'2008-08-03 09:18:57','2008-08-03 09:18:57'),(57,53,2,NULL,NULL,NULL,'2008-09-23 01:37:19','2008-09-23 01:37:19'),(58,54,2,NULL,NULL,NULL,'2008-09-23 03:25:32','2008-09-23 03:25:32'),(59,55,2,NULL,NULL,NULL,'2008-09-25 04:32:48','2008-09-25 04:32:48'),(60,56,2,NULL,NULL,NULL,'2008-10-02 06:59:41','2008-10-02 06:59:41'),(62,58,2,NULL,NULL,NULL,'2008-10-02 13:46:25','2008-10-02 13:46:25'),(63,59,2,NULL,NULL,NULL,'2008-10-02 13:53:25','2008-10-02 13:53:25'),(64,60,2,NULL,NULL,NULL,'2008-10-06 16:00:37','2008-10-06 16:00:37'),(65,61,2,NULL,NULL,NULL,'2008-10-13 04:20:56','2008-10-13 04:20:56'),(66,62,2,NULL,NULL,NULL,'2008-10-14 02:30:39','2008-10-14 02:30:39'),(67,63,2,NULL,NULL,NULL,'2008-10-14 02:41:05','2008-10-14 02:41:05'),(68,64,2,NULL,NULL,NULL,'2008-10-17 13:44:06','2008-10-17 13:44:06'),(69,65,2,NULL,NULL,NULL,'2008-10-26 10:57:41','2008-10-26 10:57:41'),(70,66,17,NULL,NULL,NULL,'2008-11-11 01:35:48','2008-11-11 01:35:48'),(71,67,2,NULL,NULL,NULL,'2008-11-13 17:04:04','2008-11-13 17:04:04'),(72,68,2,NULL,NULL,NULL,'2008-11-18 14:06:02','2008-11-18 14:06:02'),(73,69,2,NULL,NULL,NULL,'2008-11-22 14:25:39','2008-11-22 14:25:39'),(74,70,19,NULL,NULL,NULL,'2008-11-23 23:44:28','2008-11-23 23:44:28'),(75,71,19,NULL,NULL,NULL,'2008-11-23 23:49:49','2008-11-23 23:49:49'),(76,72,20,NULL,NULL,NULL,'2009-01-13 09:54:41','2009-01-13 09:54:41'),(77,73,2,NULL,NULL,NULL,'2009-01-19 09:34:46','2009-01-19 09:34:46'),(78,73,21,NULL,NULL,NULL,'2009-02-19 15:28:53','2009-02-19 15:28:53'),(79,74,2,NULL,NULL,NULL,'2009-03-01 11:37:22','2009-03-01 11:37:22'),(80,75,2,NULL,NULL,NULL,'2009-03-08 11:30:43','2009-03-08 11:30:43'),(81,76,2,NULL,NULL,NULL,'2009-03-13 10:47:40','2009-03-13 10:47:40'),(82,77,2,NULL,NULL,NULL,'2009-03-29 05:05:43','2009-03-29 05:05:43'),(83,78,2,NULL,NULL,NULL,'2009-04-14 05:28:54','2009-04-14 05:28:54'),(84,79,2,NULL,NULL,NULL,'2009-04-15 03:58:21','2009-04-15 03:58:21'),(85,80,2,NULL,NULL,NULL,'2009-04-22 04:01:57','2009-04-22 04:01:57'),(86,81,2,NULL,NULL,NULL,'2009-04-22 06:44:38','2009-04-22 06:44:38'),(87,82,2,NULL,NULL,NULL,'2009-04-24 12:27:11','2009-04-24 12:27:11'),(88,83,2,NULL,NULL,NULL,'2009-04-27 10:08:51','2009-04-27 10:08:51'),(89,84,2,NULL,NULL,NULL,'2009-04-27 10:12:22','2009-04-27 10:12:22'),(90,85,2,NULL,NULL,NULL,'2009-04-30 13:55:38','2009-04-30 13:55:38'),(91,86,5,NULL,NULL,NULL,'2009-05-03 07:37:05','2009-05-03 07:37:05'),(94,89,2,NULL,NULL,NULL,'2009-05-12 03:08:43','2009-05-12 03:08:43'),(95,90,2,NULL,NULL,NULL,'2009-05-20 08:59:37','2009-05-20 08:59:37'),(96,91,2,NULL,NULL,NULL,'2009-05-31 23:13:20','2009-05-31 23:13:20'),(97,92,2,NULL,NULL,NULL,'2009-06-12 12:04:29','2009-06-12 12:04:29'),(99,90,22,NULL,NULL,NULL,'2009-06-16 03:09:22','2009-06-16 03:09:22'),(100,94,2,NULL,NULL,NULL,'2009-06-19 12:46:25','2009-06-19 12:46:25'),(102,96,2,NULL,NULL,NULL,'2009-06-27 07:43:57','2009-06-27 07:43:57'),(103,97,2,NULL,NULL,NULL,'2009-07-14 03:40:45','2009-07-14 03:40:45'),(105,99,2,NULL,NULL,NULL,'2009-08-13 10:56:50','2009-08-13 10:56:50'),(106,100,2,NULL,NULL,NULL,'2009-08-14 06:58:09','2009-08-14 06:58:09'),(107,101,2,NULL,NULL,NULL,'2009-08-17 00:25:29','2009-08-17 00:25:29'),(108,102,2,NULL,NULL,NULL,'2009-08-17 02:03:51','2009-08-17 02:03:51');
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_info`
--

DROP TABLE IF EXISTS `schema_info`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `schema_info` (
  `version` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `schema_info`
--

LOCK TABLES `schema_info` WRITE;
/*!40000 ALTER TABLE `schema_info` DISABLE KEYS */;
INSERT INTO `schema_info` VALUES (9);
/*!40000 ALTER TABLE `schema_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `crypted_password` varchar(40) default NULL,
  `salt` varchar(40) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `remember_token` varchar(255) default NULL,
  `remember_token_expires_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@localhost','b38f333f4e300f0f91c475f3eb9cc0a08d50ca18','418efb5153905c36b1f711efb00023a335ca6022','2008-04-27 12:46:42','2008-04-27 12:46:42',NULL,NULL),(2,'mike','mike@bailey.net.au','19027a5da13e3b148268bd32720ed6f70a44bb62','8e5689f70c7742c055ba254370fb769403d43010','2008-04-27 13:20:06','2009-08-13 10:56:23','1a20f9fa34656ddaa32b27316e6b1095f40a1de8','2009-08-27 10:56:23'),(3,'test1','test@test.com','6a2f9070b0c8bdf31a234d24e63542424b953884','490ebe2b3767310426e51c55d0f0195392de02ef','2008-04-27 13:22:26','2008-04-27 13:46:09',NULL,NULL),(4,'paul_wilson1','paul_wilson1@mac.com','f769ebaae3f0221cc672581eccc5db981c7b814b','10ae1bcd3604c440501732be8f86b0e2e22690b1','2008-04-28 10:01:19','2008-04-28 10:01:19',NULL,NULL),(5,'brodaigh','brodaigh@gmail.com','35f4808c57e0cb14c87b2d0868a527bf5d490fce','1eec9a57cd6884f8ea2b264d9c635e7cb9ff30be','2008-04-28 10:09:56','2009-05-03 07:36:57','86a099cfe94cdbab9e3560ccd1b25ccf21da1250','2009-05-17 07:36:57'),(6,'louisa','louisabailey@gmail.com','d1a00c8a3dcf7e03a79edc692d374f81be8e286e','a3465a201bc217413a7acc964d6797ae2e21c133','2008-04-29 01:21:58','2008-05-26 13:41:20','fd6eb3df58494db8a46dae0fdfbbb75543a9be14','2008-06-09 13:41:20'),(7,'bryan','bryan@4gns.com','7fd3f7f3895c0a325115966be6d852e96929b500','fb09b12318e27572199fa4a39ab9f6cede80ed3a','2008-04-29 05:47:50','2008-04-29 05:47:50',NULL,NULL),(8,'mattflow','megamim@gmail.com','7c6cc12dfea6c1dab3a9c296e463d74c1bb79a77','6d520a3f5b0851c281236fbaa67a58e98a58b689','2008-04-30 09:56:09','2008-04-30 09:56:09',NULL,NULL),(9,'robertpostill','robert.postill@gmail.com','793ced75bcc6ca57eb944dd900d93363f99700fe','acd0e7b7f932ac249cd380a123fbed00b9da693e','2008-05-01 12:29:41','2008-05-01 12:29:41',NULL,NULL),(10,'dan','danlynch70@gmail.com','9ababaf5005f4f9aafc9f09f337522da52268045','47d4796288d481f6d8c830ea9aa0004fc89a12c5','2008-05-02 13:09:12','2008-05-02 13:09:12',NULL,NULL),(11,'ryan','ryan@yeahnah.org','1a46b22ffb4f871452da8ac028ad4e2528e3b9c1','65045da5cabdb6b9f4454c99c89e46c016bbae20','2008-05-09 03:52:43','2008-05-09 03:52:43',NULL,NULL),(12,'lachlanhardy','lachlan@lachstock.com.au','eef809e3a419cad8a9dbf5da65be72d35d4a27db','9fc38b731dc7c3e9641b8e56cf3c60fa93e8bcb9','2008-05-12 01:55:59','2008-05-12 01:55:59',NULL,NULL),(13,'notahat','pete@notahat.com','1088bc26e93150d9a171ee4c9b7b07b68073c99c','c366dff2032da5b47012f8f9fd7310adb720da7c','2008-05-13 04:12:34','2008-06-06 05:04:43','a9ef9e2719142add49db24007ba4775c1023d25f','2008-06-20 05:04:43'),(14,'willscarlett','punk_in_shorts@hotmail.com','5880f031a92b96d4f27b6a563c75126d5c26d2ec','3272f4b9d9b50fee85e2ab9434d55f164748ea39','2008-05-14 09:00:50','2008-05-14 09:00:50',NULL,NULL),(15,'alice','alicejmurray@gmail.com','d84d2d1114774d17287423806247c86ace618203','281c89828f6699fc5a49c81827426a30d035eae6','2008-05-27 11:05:22','2008-05-27 11:05:22',NULL,NULL),(16,'tasminw','tasminw@hotmail.com','508270e255fed18ed2e787e6cce06ddcbdcae953','e5bacd51ae05e56ccda71b4e9af98e0d1f499adf','2008-06-17 07:32:48','2008-06-17 07:36:07',NULL,NULL),(17,'c00l','megamonkey@gmail.com','c433893ecc09af369cb2f1d24064429f2bd22973','86835bf9e80836362e064cbaadf9233b6d70301b','2008-11-11 01:35:37','2008-11-11 01:35:37',NULL,NULL),(18,'paro134','parameswarsahoo@yahoo.com','f19b114e9d7ab1ba4697196d1b7d031bc9cc0b69','19152357f09aec640af6df4961f8bdf8e6f0c93a','2008-11-21 07:56:38','2008-11-21 07:56:38',NULL,NULL),(19,'Sonny','mroster@gmail.com','98bc407d780e31d9221a561813e259f62cbdf79d','1947854e10926215293d4a8dfef0df4218c7619c','2008-11-23 23:44:15','2008-11-23 23:44:15',NULL,NULL),(20,'venkat','knockusdev@gmail.com','25a710fe6e5dbbfad06fd082c9e8c6309b336cbc','33213ba62333fe123c3f00f7c7ce4a8ac0a636a2','2009-01-13 09:53:46','2009-01-13 09:53:46',NULL,NULL),(21,'goronyang13','goronyang13@gmail.com','5ffb7fcf7b8f3c2d2e1df688945438912aec32a9','bf475946504f00874fd0c50a8e2dc9c20ea894f4','2009-02-19 15:28:30','2009-02-19 15:28:30',NULL,NULL),(22,'cyberd','dave.cyberd@gmail.com','b8fe888f800e4162b956571f207083ac766c3441','cd8b0f78ccd41de25240d5acd7de31d34ec061ae','2009-06-15 20:16:59','2009-06-16 03:00:41','d2eed055df0ab63d5ecfcf386cf5106ad8a6b6ae','2009-06-30 03:00:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL auto_increment,
  `v` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `title` varchar(255) default NULL,
  `thumbnail_url` varchar(255) default NULL,
  `length_seconds` int(11) default NULL,
  `user_id` int(11) default NULL,
  `adder` int(11) default NULL,
  `private` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (2,'KMU0tzLwhbE','2008-04-27 13:46:51','2008-04-27 13:46:51','Developers','http://s4.ytimg.com/vi/KMU0tzLwhbE/default.jpg',181,NULL,2,0),(4,'bicIwwQhNtc','2008-04-28 07:13:19','2008-04-28 07:13:19','lion hug','http://i.ytimg.com/vi/bicIwwQhNtc/default.jpg',38,NULL,2,0),(8,'Y65VcABUzr8','2008-04-28 10:18:31','2008-05-02 09:26:01','419 Amazing Kid Pretty Boy Bam Bam','http://i.ytimg.com/vi/Y65VcABUzr8/default.jpg',140,NULL,5,0),(14,'wZ_MWmfWAxg','2008-04-29 12:54:58','2008-05-02 09:25:59','The Vending Machine Hack','http://i.ytimg.com/vi/wZ_MWmfWAxg/default.jpg',105,NULL,2,0),(15,'V3V4aNSuTgM','2008-04-30 09:40:15','2008-05-02 09:48:02','Sarah Silverman is addicted to cough syrup','http://i.ytimg.com/vi/V3V4aNSuTgM/default.jpg',122,NULL,2,0),(16,'8lXdyD2Yzls','2008-04-30 09:56:36','2008-04-30 09:56:36','Dramatic Gopher','http://i.ytimg.com/vi/8lXdyD2Yzls/default.jpg',6,NULL,8,0),(18,'eZjmG2-bsd8','2008-05-01 10:15:22','2008-05-01 10:15:22','Cry Baby','http://i.ytimg.com/vi/eZjmG2-bsd8/default.jpg',96,NULL,6,0),(19,'n-rWnQphPdQ','2008-05-02 02:50:11','2008-05-02 02:50:11','LSD Testing (British Troops)','http://i.ytimg.com/vi/n-rWnQphPdQ/default.jpg',97,NULL,2,0),(20,'trr7hycFbaM','2008-05-02 07:29:43','2008-05-02 09:47:59','Meadow Lea commercial (w Mojo Singers) [1982]','http://i.ytimg.com/vi/trr7hycFbaM/default.jpg',60,NULL,2,0),(21,'1hPxGmTGarM','2008-05-02 13:24:14','2008-05-08 15:14:11','Very Angry Cat - FUNNY','http://i.ytimg.com/vi/1hPxGmTGarM/default.jpg',30,NULL,10,1),(22,'14t7XZqf_es','2008-05-02 13:25:02','2008-05-02 15:46:53','Harry the Hamster','http://i.ytimg.com/vi/14t7XZqf_es/default.jpg',20,NULL,10,1),(23,'oizuxj0dhbE','2008-05-02 13:25:40','2008-05-08 15:14:09','billy the dog','http://i.ytimg.com/vi/oizuxj0dhbE/default.jpg',20,NULL,10,1),(24,'g0mSWZ_PMAI','2008-05-02 13:27:25','2008-05-02 13:27:25','The Dramatic Lemur','http://i.ytimg.com/vi/g0mSWZ_PMAI/default.jpg',21,NULL,10,0),(25,'3EpG7D59rqc','2008-05-02 13:30:12','2008-05-02 13:30:12','Bridgestone Dog','http://i.ytimg.com/vi/3EpG7D59rqc/default.jpg',61,NULL,10,0),(26,'uUcJuR_aqTs','2008-05-02 13:30:59','2008-05-02 13:30:59','Bridgestone Tire Super Bowl Commercial: Squirrel vs Car','http://i.ytimg.com/vi/uUcJuR_aqTs/default.jpg',33,NULL,10,0),(27,'VKwWrCFQdF8','2008-05-02 13:38:37','2008-05-02 13:38:37','Dog growls at  his own leg','http://i.ytimg.com/vi/VKwWrCFQdF8/default.jpg',42,NULL,10,0),(28,'tZmDWltBziM','2008-05-02 13:50:31','2008-05-02 13:53:02','THE ULTIMATE DRUNK PEOPLE COMPILATION VIDEO EVER!!!','http://i.ytimg.com/vi/tZmDWltBziM/default.jpg',131,NULL,10,1),(29,'0vC9taroEsI','2008-05-02 14:00:28','2008-05-02 14:00:28','Rabbit Rescue','http://i.ytimg.com/vi/0vC9taroEsI/default.jpg',267,NULL,6,0),(30,'lWF8KV4IW5o','2008-05-02 14:46:33','2008-05-02 14:46:33','Mountain Wingsuit','http://i.ytimg.com/vi/lWF8KV4IW5o/default.jpg',146,NULL,2,0),(31,'ONmhQJy1ViA','2008-05-09 03:52:48','2008-05-09 03:52:48','Talking Cat','http://i.ytimg.com/vi/ONmhQJy1ViA/default.jpg',21,NULL,11,0),(33,'kxsjRzf8jeU','2008-05-11 10:44:20','2008-05-11 10:44:20','Volcano.','http://i.ytimg.com/vi/kxsjRzf8jeU/default.jpg',217,NULL,5,0),(34,'_iYBmAVuBns','2008-05-12 02:09:07','2008-05-12 02:09:07','Wii Fit Parody','http://i.ytimg.com/vi/_iYBmAVuBns/default.jpg',173,NULL,5,0),(35,'VDDnuZAL9ps','2008-05-13 04:12:35','2008-05-13 04:12:35','Plaid - Itsu','http://i.ytimg.com/vi/VDDnuZAL9ps/default.jpg',219,NULL,13,0),(36,'AyoNHIl-QLQ','2008-05-13 04:13:50','2008-05-13 04:13:50','Clay Shirky - Where do people find the time Part 1','http://i.ytimg.com/vi/AyoNHIl-QLQ/default.jpg',438,NULL,13,0),(37,'SJMm4RAwVLo','2008-05-13 04:16:21','2008-05-13 04:16:21','Karen Armstrong: 2008 TED Prize wish: Charter for Compassio','http://i.ytimg.com/vi/SJMm4RAwVLo/default.jpg',1288,NULL,13,0),(38,'WuFyqzerHS8','2008-05-13 04:17:21','2008-05-13 04:17:21','Lyre Bird - Imitating Sounds - David Attenborough','http://i.ytimg.com/vi/WuFyqzerHS8/default.jpg',238,NULL,13,0),(39,'WvVfcyVCdNA','2008-05-13 14:15:57','2008-05-13 14:15:57','Illusions from Bill Nye','http://i.ytimg.com/vi/WvVfcyVCdNA/default.jpg',130,NULL,5,0),(40,'UyyjU8fzEYU','2008-05-13 14:18:54','2008-05-13 14:18:54','How it feels to have a stroke','http://i.ytimg.com/vi/UyyjU8fzEYU/default.jpg',1211,NULL,5,0),(41,'l8CEzILvtg8','2008-05-14 09:11:50','2008-05-14 09:11:50','Neg\'s Urban Sports: Urban Sprinting','http://i.ytimg.com/vi/l8CEzILvtg8/default.jpg',196,NULL,14,0),(42,'3FOqpdLYT0k','2008-05-19 15:49:46','2008-05-19 15:49:46','firework in a bag of flour','http://i.ytimg.com/vi/3FOqpdLYT0k/default.jpg',28,NULL,2,0),(43,'Fbngw8q8JLc','2008-05-22 05:42:12','2008-05-22 05:42:12','VTS Camera Car','http://i.ytimg.com/vi/Fbngw8q8JLc/default.jpg',98,NULL,2,0),(45,'Yrm2dj6bIU0','2008-05-23 15:19:33','2008-05-23 15:19:33','Charlie Brooker\'s Screenwipe - end credit squeeze','http://i.ytimg.com/vi/Yrm2dj6bIU0/default.jpg',295,NULL,2,0),(46,'36w-CyqCO1A','2008-05-26 13:41:21','2008-05-26 13:41:21','we are the world in japan','http://i.ytimg.com/vi/36w-CyqCO1A/default.jpg',224,NULL,6,0),(47,'nrlSkU0TFLs','2008-05-27 11:05:24','2008-05-27 11:05:24','FaceBook In Reality - idiotsofants.com and BBC\'sThe Wall','http://i.ytimg.com/vi/nrlSkU0TFLs/default.jpg',128,NULL,15,0),(48,'UF8uR6Z6KLc','2008-06-02 04:07:16','2008-06-02 04:07:16','Steve Jobs\' 2005 Stanford Commencement Address','http://i.ytimg.com/vi/UF8uR6Z6KLc/default.jpg',905,NULL,2,0),(49,'pmfHHLfbjNQ','2008-06-06 05:04:44','2008-06-06 05:04:44','Big Ideas: Don\'t get any - \'Nude\' by Radiohead','http://i.ytimg.com/vi/pmfHHLfbjNQ/default.jpg',235,NULL,13,0),(50,'qHr8OzaloLM','2008-06-17 07:32:55','2008-06-17 07:32:55','The End of Suburbia promo trailer','http://i.ytimg.com/vi/qHr8OzaloLM/default.jpg',166,NULL,16,0),(51,'oHXQRdjLzL0','2008-07-30 04:45:08','2008-07-30 04:45:08','Penn And Teller Cups And Balls','http://i.ytimg.com/vi/oHXQRdjLzL0/default.jpg',185,NULL,2,0),(52,'-t-5PLQgcSA','2008-08-03 09:18:56','2008-08-03 09:18:56','Are You The Favorite Person of Anybody?','http://i.ytimg.com/vi/-t-5PLQgcSA/default.jpg',244,NULL,2,0),(53,'_OBlgSz8sSM','2008-09-23 01:37:19','2008-09-23 01:37:19','Charlie bit my finger - again !','http://i4.ytimg.com/vi/_OBlgSz8sSM/default.jpg',55,NULL,2,0),(55,'W91sqAs-_-g','2008-09-25 04:32:48','2008-09-25 04:32:48','Alanis Morissette \"My Humps\" video','http://i4.ytimg.com/vi/W91sqAs-_-g/default.jpg',249,NULL,2,0),(56,'txfqWzGMgmY','2008-10-02 06:59:40','2008-10-02 06:59:40','Sarah Palin Talks Bailout Proposal','http://i1.ytimg.com/vi/txfqWzGMgmY/default.jpg',112,NULL,2,0),(58,'PWkWQ-39KLo','2008-10-02 13:46:25','2008-10-02 13:46:25','Charlie Brooker on Jamie Oliver','http://i1.ytimg.com/vi/PWkWQ-39KLo/default.jpg',113,NULL,2,0),(59,'xwIeAkEnWlg','2008-10-02 13:53:25','2008-10-02 13:53:25','Charlie Brooker\'s Screenwipe - Trapped In The Closet','http://i1.ytimg.com/vi/xwIeAkEnWlg/default.jpg',125,NULL,2,0),(60,'bXOPIbb8ZjA','2008-10-06 16:00:37','2008-10-06 16:00:37','The Screen Wipe Guide to TV','http://i3.ytimg.com/vi/bXOPIbb8ZjA/default.jpg',1740,NULL,2,0),(61,'Zn_o2AWPsck','2008-10-13 04:20:55','2008-10-13 04:20:55','More Giant Squid Fishing in San Diego Daylight','http://i3.ytimg.com/vi/Zn_o2AWPsck/default.jpg',239,NULL,2,0),(62,'kjp_jumlO3A','2008-10-14 02:30:39','2008-10-14 02:30:39','Giant Squid caught by Japanese scientists','http://i4.ytimg.com/vi/kjp_jumlO3A/default.jpg',88,NULL,2,0),(63,'tjZW4z9zqqY','2008-10-14 02:41:05','2008-10-14 02:41:05','SNL Sarah Palin Interview vs Real Sarah Palin','http://i1.ytimg.com/vi/tjZW4z9zqqY/default.jpg',171,NULL,2,0),(64,'K6NHPrYcJpo','2008-10-17 13:44:06','2008-10-17 13:44:06','Weezer Keep Fishin on ukulele','http://i4.ytimg.com/vi/K6NHPrYcJpo/default.jpg',139,NULL,2,0),(65,'je1H-57AaVg','2008-10-26 10:57:41','2008-10-26 10:57:41','Icon Persons','http://i3.ytimg.com/vi/je1H-57AaVg/default.jpg',600,NULL,2,0),(67,'Nur_fWvG4MM','2008-11-13 17:04:04','2008-11-13 17:04:04','Kimba','http://i3.ytimg.com/vi/Nur_fWvG4MM/default.jpg',44,NULL,2,0),(68,'2I0QN-FYkpw','2008-11-18 14:06:01','2008-11-18 14:06:01','Peter Schiff Was Right 2006 - 2007 (2nd Edition)','http://i3.ytimg.com/vi/2I0QN-FYkpw/default.jpg',599,NULL,2,0),(70,'3hIzQU0rAXQ','2008-11-23 23:44:28','2008-11-23 23:44:28','KRAFTWERK CANCEL SHOW - Melb 22 November','http://i4.ytimg.com/vi/3hIzQU0rAXQ/default.jpg',118,NULL,19,0),(71,'-KNrxwl59I0','2008-11-23 23:49:49','2008-11-23 23:49:49','Apple 1985 Mac Office Lemmings TV Ad','http://i2.ytimg.com/vi/-KNrxwl59I0/default.jpg',60,NULL,19,0),(72,'VRzEBiqc1dI','2009-01-13 09:54:41','2009-01-13 09:54:41','India Questions Russell Peters','http://i3.ytimg.com/vi/VRzEBiqc1dI/default.jpg',423,NULL,20,0),(73,'1qwnL5HuGWc','2009-01-19 09:34:46','2009-01-19 09:34:46','Judy Grimes Just Kidding','http://i2.ytimg.com/vi/1qwnL5HuGWc/default.jpg',114,NULL,2,0),(74,'kZzPm-DNa1I','2009-03-01 11:37:22','2009-03-01 11:37:22','Reenactment #25: Reservoir Dogs [Request #2 of List #1]','http://i4.ytimg.com/vi/kZzPm-DNa1I/default.jpg',570,NULL,2,0),(75,'WaDAPCjeNbg','2009-03-08 11:30:43','2009-03-08 11:30:43','Ja\'mie and her mum (extended)','http://i4.ytimg.com/vi/WaDAPCjeNbg/default.jpg',82,NULL,2,0),(76,'KkbxeBPJNqg','2009-03-13 10:47:39','2009-03-13 10:47:39','Gary Numan Interview Graham Norton show Funny','http://i4.ytimg.com/vi/KkbxeBPJNqg/default.jpg',361,NULL,2,0),(77,'mmsBPFUbyWg','2009-03-29 05:05:43','2009-03-29 05:05:43','Banned from TV Family Guy Clip','http://i2.ytimg.com/vi/mmsBPFUbyWg/default.jpg',171,NULL,2,0),(78,'4YBxeDN4tbk','2009-04-14 05:28:54','2009-04-14 05:28:54','Your business card is CRAP!','http://i1.ytimg.com/vi/4YBxeDN4tbk/default.jpg',130,NULL,2,0),(79,'S8yRaWY1xV8','2009-04-15 03:58:21','2009-04-15 03:58:21','Birdhouse: A notepad for Twitter','http://i4.ytimg.com/vi/S8yRaWY1xV8/default.jpg',122,NULL,2,0),(80,'rmkLlVzUBn4','2009-04-22 04:01:57','2009-04-22 04:01:57','ã‚ªã‚ªã‚«ãƒŸã¨ãƒ–ã‚¿ã€‚Stop motion with wolf and pig.','http://i3.ytimg.com/vi/rmkLlVzUBn4/default.jpg',235,NULL,2,0),(81,'Z19zFlPah-o','2009-04-22 06:44:38','2009-04-22 06:44:38','Inspired Bicycles - Danny MacAskill April 2009','http://i3.ytimg.com/vi/Z19zFlPah-o/default.jpg',338,NULL,2,0),(82,'zSP8xm_gaK4','2009-04-24 12:27:11','2009-04-24 12:27:11','New Media Douchebags Explained','http://i3.ytimg.com/vi/zSP8xm_gaK4/default.jpg',124,NULL,2,0),(83,'UWRyj5cHIQA','2009-04-27 10:08:51','2009-04-27 10:08:51','\"Rap Chop\" featuring Vince (Slap Chop remix)','http://i2.ytimg.com/vi/UWRyj5cHIQA/default.jpg',196,NULL,2,0),(84,'rUbWjIKxrrs','2009-04-27 10:12:22','2009-04-27 10:12:22','Vince with Slap Chop (Long version)','http://i3.ytimg.com/vi/rUbWjIKxrrs/default.jpg',191,NULL,2,0),(85,'2xZp-GLMMJ0','2009-04-30 13:55:38','2009-04-30 13:55:38','The Snuggie','http://i3.ytimg.com/vi/2xZp-GLMMJ0/default.jpg',121,NULL,2,0),(86,'g4YCZQav7_Q','2009-05-03 07:37:05','2009-05-03 07:37:05','My Favorite Things - Alto Saxophone','http://i4.ytimg.com/vi/g4YCZQav7_Q/default.jpg',146,NULL,5,0),(89,'wehmNVja_aI','2009-05-12 03:08:42','2009-05-12 03:08:42','Ryan Leech','http://i4.ytimg.com/vi/wehmNVja_aI/default.jpg',139,NULL,2,0),(90,'VGJt_YXIoJI','2009-05-20 08:59:37','2009-05-20 08:59:37','Built To Last','http://i3.ytimg.com/vi/VGJt_YXIoJI/default.jpg',175,NULL,2,0),(91,'GJjUVIIYptE','2009-05-31 23:13:20','2009-05-31 23:13:20','The Astounding World of the Future','http://i4.ytimg.com/vi/GJjUVIIYptE/default.jpg',293,NULL,2,0),(92,'yUY5vRj1Nns','2009-06-12 12:04:29','2009-06-12 12:04:29','Strayed: The Story of How the Animal Welfare Community Lost its Way','http://i2.ytimg.com/vi/yUY5vRj1Nns/default.jpg',1225,NULL,2,0),(94,'MT4-0JXOFfU','2009-06-19 12:46:25','2009-06-19 12:46:25','The Curiosity Show: Corrugated Cardboard Glasses','http://i2.ytimg.com/vi/MT4-0JXOFfU/default.jpg',257,NULL,2,0),(96,'GICDTG1tXt0','2009-06-27 07:43:57','2009-06-27 07:43:57','Spud Climbing','http://i4.ytimg.com/vi/GICDTG1tXt0/default.jpg',14,NULL,2,0),(97,'Oer_L09xMfc','2009-07-14 03:40:45','2009-07-14 03:40:45','Connect does The Panel','http://i4.ytimg.com/vi/Oer_L09xMfc/default.jpg',585,NULL,2,0),(99,'mT13ZcpwYtA','2009-08-13 10:56:50','2009-08-13 10:56:50','MonkeyLectric Video Pro bike wheel light display','http://i2.ytimg.com/vi/mT13ZcpwYtA/default.jpg',171,NULL,2,0),(100,'at8hZpXyykM','2009-08-14 06:58:09','2009-08-14 06:58:09','2 Live Jews - Oy\' It\'s So Humid','http://i2.ytimg.com/vi/at8hZpXyykM/default.jpg',134,NULL,2,0),(101,'5anVB-PqtuE','2009-08-17 00:25:29','2009-08-17 00:25:29','boom boom pow','http://i2.ytimg.com/vi/5anVB-PqtuE/default.jpg',210,NULL,2,0),(102,'nvIs-_HMwzg','2009-08-17 02:03:51','2009-08-17 02:03:51','It Might Get Loud movie trailer','http://i3.ytimg.com/vi/nvIs-_HMwzg/default.jpg',145,NULL,2,0);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `views`
--

DROP TABLE IF EXISTS `views`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `views` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `video_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `views`
--

LOCK TABLES `views` WRITE;
/*!40000 ALTER TABLE `views` DISABLE KEYS */;
INSERT INTO `views` VALUES (1,2,3,'2008-04-27 13:57:19','2008-04-27 13:57:19'),(2,2,4,'2008-04-28 08:43:03','2008-04-28 08:43:03'),(3,2,2,'2008-04-28 09:56:19','2008-04-28 09:56:19'),(4,4,2,'2008-04-28 10:01:48','2008-04-28 10:01:48'),(5,2,5,'2008-04-28 10:09:46','2008-04-28 10:09:46'),(6,5,8,'2008-04-28 10:31:39','2008-04-28 10:31:39'),(7,6,8,'2008-04-29 01:22:15','2008-04-29 01:22:15'),(8,6,2,'2008-04-29 01:22:31','2008-04-29 01:22:31'),(9,7,11,'2008-04-29 05:48:09','2008-04-29 05:48:09'),(10,7,8,'2008-04-29 05:48:11','2008-04-29 05:48:11'),(11,7,4,'2008-04-29 05:48:42','2008-04-29 05:48:42'),(12,5,2,'2008-04-29 12:35:57','2008-04-29 12:35:57'),(13,2,13,'2008-04-29 13:03:24','2008-04-29 13:03:24'),(14,2,15,'2008-04-30 09:40:27','2008-04-30 09:40:27'),(15,6,15,'2008-04-30 10:19:08','2008-04-30 10:19:08'),(16,2,16,'2008-04-30 12:53:36','2008-04-30 12:53:36'),(17,5,16,'2008-05-01 04:47:22','2008-05-01 04:47:22'),(18,5,15,'2008-05-01 04:48:32','2008-05-01 04:48:32'),(19,2,14,'2008-05-01 09:46:18','2008-05-01 09:46:18'),(20,9,14,'2008-05-01 12:30:57','2008-05-01 12:30:57'),(21,5,18,'2008-05-02 06:03:43','2008-05-02 06:03:43'),(22,5,20,'2008-05-02 09:26:33','2008-05-02 09:26:33'),(23,5,22,'2008-05-02 13:33:26','2008-05-02 13:33:26'),(24,2,26,'2008-05-02 13:34:29','2008-05-02 13:34:29'),(25,5,24,'2008-05-02 13:34:47','2008-05-02 13:34:47'),(26,5,25,'2008-05-02 13:34:49','2008-05-02 13:34:49'),(27,2,25,'2008-05-02 13:35:06','2008-05-02 13:35:06'),(28,5,26,'2008-05-02 13:36:01','2008-05-02 13:36:01'),(29,10,18,'2008-05-02 13:38:50','2008-05-02 13:38:50'),(30,2,24,'2008-05-02 13:40:36','2008-05-02 13:40:36'),(31,10,19,'2008-05-02 13:40:42','2008-05-02 13:40:42'),(32,2,28,'2008-05-02 13:51:51','2008-05-02 13:51:51'),(33,2,29,'2008-05-02 15:46:28','2008-05-02 15:46:28'),(34,6,18,'2008-05-03 00:11:42','2008-05-03 00:11:42'),(35,5,27,'2008-05-03 11:21:17','2008-05-03 11:21:17'),(36,5,29,'2008-05-03 17:07:51','2008-05-03 17:07:51'),(37,5,23,'2008-05-04 08:21:29','2008-05-04 08:21:29'),(38,2,31,'2008-05-09 03:58:39','2008-05-09 03:58:39'),(39,5,31,'2008-05-09 05:39:40','2008-05-09 05:39:40'),(40,2,34,'2008-05-13 07:50:33','2008-05-13 07:50:33'),(41,13,33,'2008-05-13 13:41:10','2008-05-13 13:41:10'),(42,5,38,'2008-05-13 14:16:26','2008-05-13 14:16:26'),(43,13,38,'2008-05-13 14:55:09','2008-05-13 14:55:09'),(44,13,36,'2008-05-13 15:00:07','2008-05-13 15:00:07'),(45,2,40,'2008-05-19 15:49:55','2008-05-19 15:49:55'),(46,2,39,'2008-05-19 15:58:12','2008-05-19 15:58:12'),(47,2,38,'2008-05-20 12:37:12','2008-05-20 12:37:12'),(48,2,41,'2008-05-20 23:55:29','2008-05-20 23:55:29'),(49,15,46,'2008-05-27 11:05:34','2008-05-27 11:05:34'),(50,15,34,'2008-05-27 11:08:27','2008-05-27 11:08:27'),(51,2,37,'2008-05-28 11:44:39','2008-05-28 11:44:39'),(52,6,38,'2008-05-31 11:24:26','2008-05-31 11:24:26'),(53,13,49,'2008-06-08 04:58:51','2008-06-08 04:58:51'),(54,2,54,'2008-09-23 04:00:30','2008-09-23 04:00:30'),(55,2,53,'2008-09-23 04:00:57','2008-09-23 04:00:57'),(56,2,55,'2008-10-02 13:25:12','2008-10-02 13:25:12'),(57,2,45,'2008-10-02 13:34:20','2008-10-02 13:34:20'),(58,2,57,'2008-10-03 04:33:55','2008-10-03 04:33:55'),(59,2,65,'2008-10-26 10:57:48','2008-10-26 10:57:48'),(60,2,66,'2008-11-13 17:04:16','2008-11-13 17:04:16'),(61,2,64,'2008-11-18 05:11:20','2008-11-18 05:11:20'),(62,2,63,'2008-11-18 05:21:16','2008-11-18 05:21:16'),(63,19,58,'2008-11-23 23:46:37','2008-11-23 23:46:37'),(64,2,70,'2008-11-26 05:10:06','2008-11-26 05:10:06'),(65,20,67,'2009-01-13 09:53:59','2009-01-13 09:53:59'),(66,20,68,'2009-01-13 09:56:05','2009-01-13 09:56:05'),(67,2,83,'2009-04-30 13:56:14','2009-04-30 13:56:14'),(68,2,84,'2009-04-30 13:58:57','2009-04-30 13:58:57'),(69,2,85,'2009-04-30 14:07:04','2009-04-30 14:07:04'),(70,2,82,'2009-05-01 05:51:17','2009-05-01 05:51:17'),(71,2,86,'2009-05-20 08:59:42','2009-05-20 08:59:42'),(72,22,91,'2009-06-15 20:17:06','2009-06-15 20:17:06'),(73,22,14,'2009-06-16 03:02:51','2009-06-16 03:02:51'),(74,22,8,'2009-06-16 03:02:55','2009-06-16 03:02:55'),(75,22,42,'2009-06-16 03:03:23','2009-06-16 03:03:23'),(76,22,93,'2009-06-16 03:06:24','2009-06-16 03:06:24'),(77,2,92,'2009-06-27 07:46:49','2009-06-27 07:46:49'),(78,2,101,'2009-08-17 12:43:39','2009-08-17 12:43:39');
/*!40000 ALTER TABLE `views` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-05-05  6:35:23
